import React, { Component} from 'react';
import './App.css';
class App extends Component {
  render() {
  return (
    <div className = "cover">
      <head>
        <title>Judy Zhang</title>
      </head>
      <body>
        <ul>
          <li>JZ</li>
          <li>Home</li>
          <li>About Me</li>
          <li>Gallery</li>
         </ul>
        </body>
      </div>
  );
  }
}

export default App;

